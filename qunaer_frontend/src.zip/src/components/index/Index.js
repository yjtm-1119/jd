import React from 'react';
function Index(){
    return ( 
      <div>
        首页
      </div>
     );
}
 
export default Index;