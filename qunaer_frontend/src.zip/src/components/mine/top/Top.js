import React from 'react';
import './Top.css';
function Top() {
  return (
    <div className="top">
      
    </div>
  )
}

export default Top;