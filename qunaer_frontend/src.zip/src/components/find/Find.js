import React from 'react';
function Find(){
    return ( 
      <div>
        发现
      </div>
     );
}
 
export default Find;