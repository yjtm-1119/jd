import React from 'react';
function Cart(){
    return ( 
      <div>
        购物车
      </div>
     );
}
 
export default Cart;