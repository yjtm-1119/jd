export const CHANGE_INPUT = 'changeInput'
export const ADD_ITEM='addItem'
export const DELETE_ITEM = 'deleteItem'
export const GET_LIST = 'getList'